var assert = require('assert');

module.exports = {
  demoTest : function (done) {
    assert.equal(1, 0);
  }
};
